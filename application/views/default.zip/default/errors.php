
<div class="main-cont"> 

  <section class="inner-banner-content">
    <div class="container">
      <div class="row">
        <div class="col-md-12 banner-ele">
          

          <!-- <h4 class="animate flipInX">About Us</h4> -->
          <h1 class="animate flipInX" data-wow-delay="1s">404 Error</h1>
         
          
        </div>
      </div>
    </div>
  </section>

  <section class="content info-sec animate slideInUp">
    <div class="container">
      <div class="row cntr-content">
        <div class="col-md-12">
          <div class="heading-sep">
            <span class="seperator-left"></span>              
          </div>
          <h2>404</h2>
          <p class="mbpx-0">Page Not Found</p>
        </div>
      </div>
    </div>
  </section>

